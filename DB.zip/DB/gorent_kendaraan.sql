-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: gorent
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kendaraan`
--

DROP TABLE IF EXISTS `kendaraan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kendaraan` (
  `id` varchar(10) NOT NULL,
  `merk` varchar(100) NOT NULL,
  `tipe` varchar(100) NOT NULL,
  `tahun` int(11) NOT NULL,
  `transmisi` varchar(50) NOT NULL,
  `bahan_bakar` varchar(50) NOT NULL,
  `harga_sewa` int(11) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Tersedia' COMMENT 'Isinya ''Tersedia'' atau ''Disewa''',
  `image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kendaraan`
--

LOCK TABLES `kendaraan` WRITE;
/*!40000 ALTER TABLE `kendaraan` DISABLE KEYS */;
INSERT INTO `kendaraan` VALUES ('K001','Toyota','Terios',2023,'Manual','Bensin',1000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\terios.png'),('K002','Toyota','Kijang Innova',2020,'Manual','Bensin',2000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\innova.jpeg'),('K003','Toyota','Avanza',2023,'Matic','Bensin',1500000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\avanza.jpg'),('K004','Daihatsu','Sigra',2017,'Matic','Bensin',1000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\sigra.jpg'),('K005','Toyota','Vellfire',2020,'Matic','BEnsin',3000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\vellfire.jpeg'),('K006','Honda','Mobilio',2019,'Matic','Bensin',1200000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\mobilio.jpeg'),('K007','Mitsubishi','Xpander',2021,'Matic','Bensin',1100000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\xpander.jpeg'),('K008','Wuling','Almaz',2023,'Matic','Bensin',1000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\almaz.jpeg'),('K009','Suzuki','Ertiga',2020,'Matic','Bensin',9000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\ertiga.png'),('K010','Toyota','Sienta',2016,'Matic','Bensin',800000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\sienta.jpeg'),('K011','Toyota','Corrolla Altiz',2024,'Matic','Hybrid',2000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\altiz.jpg'),('K012','Hyundai','Ioniq 6',2025,'Matic','Electric',4000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\ioniq 6.jpeg'),('K013','Hyundai','Ioniq 5',2023,'Matic','Electric',3000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\ioniq 5.jpeg'),('K014','Wuling','Air EV',2024,'Matic','Electic',1300000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\wuling air ev.jpeg'),('K015','Honda','Revo',2018,'Manual','Bensin',200000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\revo.jpeg'),('K017','Honda','Beat',2024,'Matic','Bensin',400000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\beat.jpg'),('K018','Honda','Vario 160',2025,'Matic','Bensin',600000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\vario.jpg'),('K019','Honda','ADV 160',2023,'Matic','Bensin',500000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\ADV.jpeg'),('K020','Honda','PCX 160 ABS',2024,'Matic','Bensin',700000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\PCX.jpeg'),('K021','Yamaha','Mio S',2017,'Matic','Bensin',560000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\mio.jpeg'),('K022','Suzuki','NEX II',2023,'Matic','Bensin',600000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\Suzuki-NEX-II.jpg'),('K023','Yamaha','Aerox 160',2025,'Matic','Bensin',800000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\tampilan-depan-yamaha-aerox.jpg'),('K024','Honda','Scoopy',2023,'Matic','Bensin',500000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\scoppy.jpeg'),('K025','Suzuki','Hayabusa 1000R',2016,'Manual','Bensin',5000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\hayabusa.png'),('K026','McLaren','570GT',2021,'Manual','Bensin',30000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\McLaren-570GT-Mulai-Debutnya-di-Inggris.png'),('K027','Lamborghini','Aventador Performante',2017,'Manual','Bensin',35000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\lamborghini-aventador-lp-780-4-ultimae.jpg'),('K028','Aston Martin','DB11',2020,'Matic','Bensin',20000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\astonmartin.jpeg'),('K029','BMW','i8 Electric',2019,'Manual','Electric',15000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\bmwi8.jpg'),('K030','Tesla','Roadster S',2024,'Matic','Electroc',13000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\roadster.jpg'),('K031','Tesla','All New Cybertruck',2023,'Matic','Electric',23000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\cybertruck.jpeg'),('K032','Toyota','All New C-HR',2025,'Matic','Electric',1500000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\chr.png'),('K033','Xiaomi','SU7 Turbo',2025,'Manual/Matic','Electric',20000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\su7.jpg'),('K034','Honda','Goldwing R1000',2012,'Manual','Bensin',21000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\goldwing.jpeg'),('K035','Kawasaki','H2R Carbon',2019,'Manual','Bensin',15000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\H2R.jpg'),('K036','Yamaha','R1M',2018,'Manual','Bensin',12000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\4afc2ee121aab0f0d791c1f328d64b04918e00bc_xlarge_21a51a65e0.jpg'),('K037','Ducati','Panigale V4R',2015,'Manual','Bensin',20000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\panigale.jpeg'),('K038','Alva','Alva One',2025,'Matic','Electric',500000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\motor-listrik-alva.jpg'),('K039','Honda','Super Cub 110cc',2000,'Manual','Bensin',800000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\cube.jpg'),('K040','Honda','Supra GTR 150',2024,'Manual','Bensin',300000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\gtr 150.jpeg'),('K041','Honda','Sc e',2025,'Matic','Electric',400000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\sc.jpeg'),('K042','Kawasaki','KLX 150',2023,'Manual','Bensin',600000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\klx.jpg'),('K043','Honda','CBR 250RR',2024,'Manual','Bensin',1000000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\cbr.png'),('K044','Yamaha','Lexi',2020,'Matic','Bensin',300000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\lexi.png'),('K045','Suzuki','Hayate',2018,'Matic','Bensin',200000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\hayate.jpeg'),('K046','Suzuki','Satria F150',2020,'Manual','Bensin',350000,'Tersedia','C:\\Users\\viery\\OneDrive\\Dokumen\\College\\PBO\\GoRent\\image\\satria.jpg');
/*!40000 ALTER TABLE `kendaraan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05 10:22:54
